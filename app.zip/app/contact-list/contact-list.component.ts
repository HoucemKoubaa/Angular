import { NgSwitch, NgSwitchCase } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {Contact} from '../models/Contact';
listContacts:Array<Contact>;
@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})

export class ContactListComponent implements OnInit {
  
  constructor() { 
    this.setMarkContactStyle(); 
    this.createContact();
  } isMarked = true;
  isFriendContact = true; 
  isFamilyContact = false; 
  isWorkContact = true; 

  
  markContactStyle: Record<string, string> = {}; 
  setMarkContactStyle() { 
    this.markContactStyle = { 
      'font-style': this.isFriendContact ? 'italic' : 'normal', 
      'font-weight': !this.isFamilyContact ? 'bold' : 'normal', 
      'font-size': this.isWorkContact ? '24px' : '12px' 
    } 
  }



  listContacts: Array<Contact> = new Array<Contact>(); 
  createContact() 
  { 
  let contact1 = new Contact(1,"Houcem", "koubaa", "Houcem994'@gmail.com", "Friend", "Amis", "27771933"); 
  this.listContacts.push(contact1);

  let contact2 = new Contact(2,"zied", "kallel", "zied@gmail.com", "Friend", "Amis", "98559121"); 
  this.listContacts.push(contact2);

  let contact3 = new Contact(3,"Mohamed", "tawfik Msedi", "mohamed@gmail.com", "Work", "Travail", "98559121"); 
  this.listContacts.push(contact3);

  let contact4 = new Contact(4,"Omar", "Ghorbel", "omar@hotmail.com", "Work", "Travail", "98559121"); 
  this.listContacts.push(contact4);

  let contact5 = new Contact(5,"Walid", "Gharbi", "walid@hotmail.com", "Family", "Family", "98559121"); 
  this.listContacts.push(contact5);

  let contact6 = new Contact(6,"Hassan", "Touati", "hassan@hotmail.com", "Family", "Family", "98559121"); 
  this.listContacts.push(contact6);

  let contact7 = new Contact(7,"Hassan", "Touati", "hassan@hotmail.com", "Family", "Family", "98559121"); 
  this.listContacts.push(contact7);

  let contact8 = new Contact(8,"Hassan", "Touati", "hassan@hotmail.com", "Family", "Family", "98559121"); 
  this.listContacts.push(contact8);
  
  let contact9 = new Contact(9,"Hassan", "Touati", "hassan@hotmail.com", "Family", "Family", "98559121"); 
  this.listContacts.push(contact9);

  }
  /*
  deleteContact(): void { 
    let reponse = confirm("Voulez-vous supprimer le contact"); 
    if (reponse) { 
      alert("Contact Supprimé"); 
    } else { 
      alert("Action annulé"); 
    } 
  }*/
  ngOnInit(): void {
  }


  deleteContact(id:number):void{ 
    let index:number=-1;
    for(let c of this.listContacts){ 
      index = index+1; 
      if(c.id==id){ 
        break; 
      } 
    } 
    if(index!=-1){ 
      this.listContacts.splice(index,1); 
    } 
  }


  
  /*
  deleteContact():void{ 
    let reponse =confirm("Voulez-vous supprimer le contact"); 
    if (reponse==true){
      alert("Contact supprimé")}
    else{
      alert("Contact non supprimé")} 
  }
  */
  EditContact():void{ 
    let reponse =confirm("Voulez-vous Editer le contact"); 
    if (reponse==true){
      alert("Contact Editer")}
    else{
      alert("Contact non Editer")} 
  }
}
