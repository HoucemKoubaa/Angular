import { Injectable } from '@angular/core';
import { Contact } from '../models/Contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  listContacts: Array<Contact> = new Array<Contact>(); 
  /** * Create fake contact list */ 
  createContact() { 
    let contact = new Contact(1, "Ali", "Mohamed", "ali.mohamed@XXX.com", "Friend", "Un ami", "98XXXXXX"); 
    this.listContacts.push(contact);
}
  constructor() { }
}
